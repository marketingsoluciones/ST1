Thankyou for purchasing my file!



Instructions :


1. download te zip file and extract it to specified folder
2. choose mainfile folder and open it
3. download the font here : 
- https://www.fontsquirrel.com/fonts/montserrat
4. click the source file and bingo!
5. enjoy it!! 



Thank you