Thankyou for purchasing my file!



Instructions :


1. Extract the Zip file
2. Open the AI or EPS file with Adobe Illustrator
3. download the font here https://www.fontsquirrel.com/fonts/montserrat
4. You can edit the text stroke effect through Window > Appearance. (If Any)
5. Also you can edit the additional parts (if any) through Window > Layers, You can activate/Deactivate the layer.


Thankyou!