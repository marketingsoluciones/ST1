Thank you for purchasing my file!


Instructions :


1. download the zip file and extract it to specified folder
2. fonts : montserrat ( download font here : https://www.fontsquirrel.com/fonts/montserrat )
3. click the source file and bingo! 
4. enjoy it!!


Easy colors changing via Live Color or Recolor Artwork in Illustrator :


1. select a range of object and then choose Edit > Edit Colors > Recolor Artwork you will bring up the recolor dialog box
2. from the tabs on the top choose the Edit tab, then click the Link Colors chain icon in the middle center of the dialog
3. then set the sliders to HSB
4. and then you can adjust the Hue, Saturation and Brightness sliders to change the colors uniformly
5. lastly click OK and it's done 


Thank you and don't forget to rate my item!


Best regards,

Putra_Purwanto